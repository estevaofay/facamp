package br.com.facamp.com747;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MazeSolver {

	List<Node> fringe = new ArrayList<>();
	List<Node> closedList = new ArrayList<>();
	Node[][] closedMap;
	
	public Node search(Node initialNode) {
		closedMap = new Node[initialNode.maze.getNRows()][initialNode.maze.getNCols()];
		fringe.add(initialNode);
		do {
			if (fringe.isEmpty())
				return null;
			Node n = fringe.remove(0);
			System.out.println(n.x+" "+n.y+" "+n.f()+"="+n.g()+"+"+n.h()+" "+fringe.size()+" "+closedList.size());
			closedList.add(n);
			if (n.h()<0.0001)
				return n;
			List<Node> child = n.generatePossibleMoves();
			show(n,child);
			for(Node c : child) {
				boolean shouldIncludeInFringe = false;
				if (closedMap[c.y][c.x]==null || closedMap[c.y][c.x].f()>c.f()) {
					shouldIncludeInFringe = true;
					closedMap[c.y][c.x] = c;
				}
				if (shouldIncludeInFringe){
					int index = Collections.binarySearch(fringe, c);
					if(index<0)
						index=-(index+1);
					fringe.add(index, c);
				}
			}
		} while(!fringe.isEmpty());
		return null;
		
	}
	public void show(Node n, List<Node>child) {
		Maze m = new Maze(n.maze);
		while(n!=null) {
			m.addPoint(n.x, n.y);
			n = n.parent;
		}
		if (child!=null)
			for(Node nn : child)
				m.addOption(nn.x, nn.y);
		m.display();
	}
	
	public static void main(String[] args) {
		Maze m = new Maze(8,8,1,1,31,15);
		m.display();
		Node n = new Node(null,m,1,1);
		
		MazeSolver ms = new MazeSolver();
		Node result = ms.search(n);
		if (result==null)
			System.out.println("NOT FOUND!");
		else {
			ms.show(result,null);
		}
		
	}
	
}
