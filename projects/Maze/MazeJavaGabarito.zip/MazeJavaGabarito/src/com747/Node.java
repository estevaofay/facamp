package br.com.facamp.com747;

import java.util.ArrayList;
import java.util.List;

public class Node implements Comparable<Node>{
	Node parent;
	Maze maze;
	int x;
	int y;
	private double g;
	private double h = -1;
	
	public Node(Node parent, Maze maze, int x, int y) {
		super();
		this.parent = parent;
		this.maze = maze;
		this.x = x;
		this.y = y;
		if (parent==null)
			this.g = 0;
		else
			this.g = parent.g()+dist(x,y,parent.x,parent.y);
		h = dist(x,y,maze.getDestinationX(),maze.getDestinationY());
	}
	
	private double dist(int x1, int y1, int x2, int y2) {
		return Math.sqrt(Math.pow(x1-x2, 2)+Math.pow(y1-y2,2));
	}
	
	public double g() {
		return g;
	}
	public double f() {
		return g+h;
	}
	
	public double h() {
		return h;
	}
		
	public List<Node> generatePossibleMoves() {
		List<Node> ret = new ArrayList<>();
		addMove(x+1, y, ret);
		addMove(x+1, y+1, ret);
		addMove(x, y+1, ret);
		addMove(x-1, y+1, ret);
		addMove(x-1, y, ret);
		addMove(x-1, y-1, ret);
		addMove(x, y-1, ret);
		addMove(x+1, y-1, ret);
		return ret;
	}
	private void addMove(int x, int y, List<Node> ret) {
		if (parent!=null && parent.x==x && parent.y==y)
			return;
		if (maze.isEmpty(x, y))
			ret.add(new Node(this,maze,x,y));
	}

	@Override
	public int compareTo(Node o) {
		double diff = this.f() - o.f();
		if (Math.abs(diff)<0.000001)
			diff = 0;
		return (int) Math.signum(diff);
	}

	@Override
	public String toString() {
		return "Node [x=" + x + ", y=" + y + ", g=" + g + ", h=" + h + "]";
	}
	
}
